import sqlite3

# Connect to your database
conn = sqlite3.connect("students.db")
cursor = conn.cursor()

# Delete all rows from email_templates table
cursor.execute("DELETE FROM email_templates")
conn.commit()

# Optionally, check how many rows were affected:
print("Rows deleted:", cursor.rowcount)

# Close the connection
conn.close()
