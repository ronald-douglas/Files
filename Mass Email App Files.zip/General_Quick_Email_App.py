import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import sqlite3
import pandas as pd
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from PIL import Image, ImageTk  # For loading and resizing JPG logos

# ---------------------------
# Theme and Design Configuration
# ---------------------------
PRIMARY_BG = "#800020"   # Burgundy
ACCENT = "#808080"       # Gray
TEXT_COLOR = "white"     # White text for dark backgrounds
BUTTON_BG = "white"      # White button background for contrast
BUTTON_FG = "#800020"    # Burgundy text on buttons
LISTBOX_BG = "white"
LISTBOX_FG = "black"

# Database file name
DB_NAME = "students.db"

def initialize_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    cursor.execute('''CREATE TABLE IF NOT EXISTS students (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL,
                        parent_email TEXT NOT NULL)''')
    
    cursor.execute('''CREATE TABLE IF NOT EXISTS email_templates (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        template_name TEXT NOT NULL,
                        subject TEXT NOT NULL,
                        body TEXT NOT NULL)''')
    
    conn.commit()
    conn.close()
    add_default_templates()

def add_default_templates():
    """
    Insert default email templates if none exist.
    The "Unsatisfactory Grade" template uses a triple-quoted string to store the full message.
    A new template "Unprepared for Class" has been added with the specified contents.
    """
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM email_templates")
    if cursor.fetchone()[0] == 0:
        templates = [
            ("Academic Dishonesty", "Student Report - Academic Dishonesty (NOREPLY)",
             "Good morning parent or guardian,\n\n"
             "This is Mr. Douglas (math) at McKinley Technology High School. This is a quick notification that your student was found cheating or using AI on an assignment in class today. "
             "If this behavior continues, you will be notified again via email. Academic dishonesty can be in the form of copying from a classmate, plagiarism, submitting AI-generated answers as their own work, or other methods consistent with cheating. Future repeated infractions of this type could lead to a referral.\n\n"
             "Mr. Douglas (math)"),
            ("Class Disruption", "Student Report - Class Disruption (NOREPLY)",
             "Good morning parent or guardian,\n\n"
             "This is Mr. Douglas (math) at McKinley Technology High School. This is a quick notification that your student disrupted class today. "
             "Class disruption can be in the form of horseplay, talking at inappropriate times, distracting classmates, and other off-task behaviors. Please remind your student that future repeated classroom disruptions could result in a referral.\n\n"
             "Regards,\nMr. Douglas (math)"),
            ("Disrespect/Defiance", "Student Report - Disrespect/Defiance (NOREPLY)",
             "Good morning parent or guardian,\n\n"
             "This is Mr. Douglas (math) at McKinley Technology High School. This is a quick notification that your student was disrespectful/defiant toward the teacher in class today. "
             "Disrespect/Defiance can be in the form of using an aggressive tone with the teacher, talking back, refusing to follow instructions, and other behaviors that would be considered disrespectful if done toward an adult. Future repeated infractions of this type could lead to a referral.\n\n"
             "Mr. Douglas (math)"),
            ("Skipping Class", "Student Report - Skipping Class (NOREPLY)",
             "Good morning parent or guardian,\n\n"
             "This is Mr. Douglas (math) at McKinley Technology High School. This is a quick notification that your student was skipping a portion of class today. "
             "Skipping can be in the form of unreasonably lengthy bathroom trips, arriving to class tardy without prior permission from Mr. Douglas/counselor/admin, leaving class early without permission, or other behaviors that students engage in to avoid class. Future repeated infractions of this type could lead to a referral.\n\n"
             "Mr. Douglas (math)"),
            ("Sleeping in Class", "Student Report - Sleeping in Class (NOREPLY)",
             "Good morning parent or guardian,\n\n"
             "This is Mr. Douglas (math) at McKinley Technology High School. This is a quick notification that your student had their head down or was sleeping in class today and did not participate in part/all of the lesson. If this behavior continues, you will be notified again via email.\n\n"
             "Regards,\nMr. Douglas (math)"),
            ("Tardy/Late", "Student Report - Tardy/Late (NOREPLY)",
             "Good morning parent or guardian,\n\n"
             "This is Mr. Douglas (math) at McKinley Technology High School. This is a quick notification that your student was tardy/late to class today. Tardiness causes students to miss key parts of the lesson or assignment so it is critical that they arrive to class on time.\n\n"
             "Regards,\nMr. Douglas (math)"),
            ("Unprepared for Class", "Student Report - Unprepared for Class (NOREPLY)",
             """Good morning parent or guardian,

This is Mr. Douglas (math) at McKinley Technology High School. This is a quick notification that your student came unprepared to class today. If this behavior continues, you will be notified again via email. Unpreparedness can be in the form of forgetting their school issued laptop, class binder, homework assignments, or other tools necessary for in class success. Future infractions of this type could negatively impact success on assessments and graded activities.

Regards,

Mr. Douglas"""),
            ("Unsatisfactory Grade", "Student Report – Unsatisfactory Grade (NOREPLY)",
             """Good morning parent or guardian,

This is Mr. Douglas (math) at McKinley Technology High School. This is a quick notification that your student is earning consistently unsatisfactory grades in math class. If this behavior continues, you will be notified again via email. Unsatisfactory grades are the result of failing to complete homework each night, failure to check work against the homework answer keys, failure to study for homework checks or quizzes, failure to attend power hour tutoring, and/or failure to watch PlayPosit tutorial videos. Future infractions of this type could negatively impact a student's success on assessments and graded activities. Please check Aspen for unsatisfactory grades like WS (missing/waiting for submission – 50%), 63% (failed the original assignment and has not revised for a higher grade), and 76% (failed the original assignment and has revised for a higher grade). I have spent the summer compiling these additional resources to help students reinforce what we learn in class. Not taking advantage of these learning opportunities suggests that students are not working to their full potential inside or outside of class, which will result in lower grades. Power Hour is M-Th from 3:30-4:30 PM (My day is Tuesday). I will continue to encourage your scholar to make a better effort in these areas.

Regards,

Mr. Douglas (math)""")
        ]
        cursor.executemany("INSERT INTO email_templates (template_name, subject, body) VALUES (?, ?, ?)", templates)
        conn.commit()
    conn.close()

def send_email(recipient, subject, body):
    sender_email = "douglrj0@sewanee.edu"
    sender_password = "aymd kxsm vumc_fkrs"
    
    msg = MIMEMultipart()
    msg["From"] = sender_email
    msg["To"] = recipient
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain", "utf-8"))

    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, recipient, msg.as_string())
        server.quit()
        print(f"✅ Email successfully sent to {recipient}")
        return True
    except Exception as e:
        print(f"❌ Error sending email: {e}")
        return False

initialize_db()

# Define theme colors
PRIMARY_BG = "#800020"   # Burgundy
ACCENT = "#808080"       # Gray
TEXT_COLOR = "white"
BUTTON_BG = "white"
BUTTON_FG = "#800020"
LISTBOX_BG = "white"
LISTBOX_FG = "black"

class EmailApp:
    def __init__(self, root):
        self.root = root
        self.root.title("McKinley Quick Email App")
        self.root.geometry("600x700")  # Increased height for better visibility
        self.root.configure(bg=PRIMARY_BG)
        self.upload_page()

    def upload_page(self):
        for widget in self.root.winfo_children():
            widget.destroy()
        tk.Label(self.root, text="Upload Student Database", font=("Arial", 16), bg=PRIMARY_BG, fg=TEXT_COLOR).pack(pady=10)
        tk.Button(self.root, text="Upload Spreadsheet", command=self.upload_students, bg=BUTTON_BG, fg=BUTTON_FG).pack(pady=10)
        tk.Button(self.root, text="Clear Student Data", command=self.clear_database, bg=BUTTON_BG, fg=BUTTON_FG).pack(pady=10)
        tk.Button(self.root, text="Continue", command=self.selection_page, bg=BUTTON_BG, fg=BUTTON_FG).pack(pady=10)

    def upload_students(self):
        file_path = filedialog.askopenfilename(filetypes=[("Excel Files", "*.xlsx")])
        if not file_path:
            return
        df = pd.read_excel(file_path)
        if "Student Name" not in df.columns or "Parent Email" not in df.columns:
            messagebox.showerror("Error", "Excel file must contain 'Student Name' and 'Parent Email' columns.")
            return
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM students")
        for _, row in df.iterrows():
            cursor.execute("INSERT INTO students (name, parent_email) VALUES (?, ?)", (row["Student Name"], row["Parent Email"]))
        conn.commit()
        conn.close()
        messagebox.showinfo("Success", "Student database uploaded successfully!")

    def clear_database(self):
        if messagebox.askyesno("Confirm", "Are you sure you want to clear all student data from the database?"):
            conn = sqlite3.connect(DB_NAME)
            cursor = conn.cursor()
            cursor.execute("DELETE FROM students")
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", "Student data cleared!")

    def selection_page(self):
        for widget in self.root.winfo_children():
            widget.destroy()
        tk.Label(self.root, text="Select Students", font=("Arial", 14), bg=PRIMARY_BG, fg=TEXT_COLOR).pack()
        self.student_listbox = tk.Listbox(self.root, selectmode=tk.MULTIPLE, width=50, height=10, bg=LISTBOX_BG, fg=LISTBOX_FG)
        self.student_listbox.pack(pady=5)
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM students")
        students = cursor.fetchall()
        conn.close()
        for student in students:
            self.student_listbox.insert(tk.END, student[0])
        tk.Label(self.root, text="Select Email Template", font=("Arial", 14), bg=PRIMARY_BG, fg=TEXT_COLOR).pack(pady=5)
        self.template_var = tk.StringVar()
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("SELECT template_name FROM email_templates")
        templates = [t[0] for t in cursor.fetchall()]
        conn.close()
        self.template_dropdown = ttk.Combobox(self.root, textvariable=self.template_var, values=templates)
        self.template_dropdown.pack(pady=10)
        # Add a text entry for teacher name
        tk.Label(self.root, text="Enter Teacher Name:", font=("Arial", 14), bg=PRIMARY_BG, fg=TEXT_COLOR).pack(pady=5)
        self.teacher_entry = tk.Entry(self.root, font=("Arial", 12))
        self.teacher_entry.pack(pady=5)
        # Add a text entry for course name (to replace "(math)")
        tk.Label(self.root, text="Enter Course Name:", font=("Arial", 14), bg=PRIMARY_BG, fg=TEXT_COLOR).pack(pady=5)
        self.course_entry = tk.Entry(self.root, font=("Arial", 12))
        self.course_entry.pack(pady=5)
        button_frame = tk.Frame(self.root, bg=PRIMARY_BG)
        button_frame.pack(pady=10)
        tk.Button(button_frame, text="Back", command=self.upload_page, bg=BUTTON_BG, fg=BUTTON_FG).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Next", command=self.summary_page, bg=BUTTON_BG, fg=BUTTON_FG).pack(side=tk.RIGHT, padx=5)

    def summary_page(self):
        teacher_name = self.teacher_entry.get()
        course_name = self.course_entry.get()
        selected_students = [self.student_listbox.get(idx) for idx in self.student_listbox.curselection()]
        selected_template = self.template_var.get()
        if not selected_students or not selected_template:
            messagebox.showerror("Error", "Select at least one student and one template.")
            return
        for widget in self.root.winfo_children():
            widget.destroy()
        tk.Label(self.root, text="Email Summary", font=("Arial", 14), bg=PRIMARY_BG, fg=TEXT_COLOR).pack(pady=10)
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("SELECT subject, body FROM email_templates WHERE template_name=?", (selected_template,))
        subject, body = cursor.fetchone()
        conn.close()
        # Replace teacher name if provided
        if teacher_name.strip():
            subject = subject.replace("Mr. Douglas", teacher_name)
            body = body.replace("Mr. Douglas", teacher_name)
        # Replace "(math)" with the entered course name in parentheses (if provided)
        if course_name.strip():
            subject = subject.replace("(math)", "(" + course_name + ")")
            body = body.replace("(math)", "(" + course_name + ")")
        summary_text = ""
        for student in selected_students:
            conn = sqlite3.connect(DB_NAME)
            cursor = conn.cursor()
            cursor.execute("SELECT parent_email FROM students WHERE name=?", (student,))
            recipient = cursor.fetchone()[0]
            conn.close()
            summary_text += f"Student: {student}\nTo: {recipient}\nSubject: {subject}\n\n{body}\n{'-'*50}\n"
        summary_frame = tk.Frame(self.root)
        summary_frame.pack(expand=True, fill=tk.BOTH, pady=10)
        summary_box = tk.Text(summary_frame, wrap=tk.WORD, bg="white", fg="black")
        summary_box.insert(tk.END, summary_text)
        summary_box.config(state=tk.DISABLED)
        summary_box.pack(side=tk.LEFT, expand=True, fill=tk.BOTH)
        scrollbar = tk.Scrollbar(summary_frame, orient=tk.VERTICAL, command=summary_box.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        summary_box.config(yscrollcommand=scrollbar.set)
        button_frame = tk.Frame(self.root, bg=PRIMARY_BG)
        button_frame.pack(pady=10)
        tk.Button(button_frame, text="Back", command=self.selection_page, bg=BUTTON_BG, fg=BUTTON_FG).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Send Emails", command=lambda: self.send_emails(selected_students, subject, body), bg=BUTTON_BG, fg=BUTTON_FG).pack(side=tk.RIGHT, padx=5)

    def send_emails(self, students, subject, body):
        if messagebox.askyesno("Confirm", "Are you sure you want to send these emails?"):
            for student in students:
                conn = sqlite3.connect(DB_NAME)
                cursor = conn.cursor()
                cursor.execute("SELECT parent_email FROM students WHERE name=?", (student,))
                recipient = cursor.fetchone()[0]
                conn.close()
                if not send_email(recipient, subject, body):
                    messagebox.showerror("Error", f"Failed to send email to {student}.")
            messagebox.showinfo("Success", "Emails sent successfully!")
        self.upload_page()

if __name__ == "__main__":
    root = tk.Tk()
    root.configure(bg=PRIMARY_BG)
    app = EmailApp(root)
    root.mainloop()
